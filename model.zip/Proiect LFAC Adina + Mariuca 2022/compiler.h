
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

extern char *yytext;

extern int countn;
int count = 0;
int q;
char type[100];

struct dataType
{
    char *id_name;
    char *data_type;
    char *type;
    int value;
    bool inMain;
    bool inFunction;
} symbol_table[40];

void drawTable()
{
    printf("\nSYMBOL           DATATYPE      TYPE       VALUE         \n");
    printf("__________________________________________________________\n\n");

    int i = 0;

    for (i = 0; i < count; i++)
    {
        printf("%s\t%s\t%s\t%d\t\n", symbol_table[i].id_name, symbol_table[i].data_type, symbol_table[i].type, symbol_table[i].value);
    }

    for (i = 0; i < count; i++)
    {
        free(symbol_table[i].id_name);
        free(symbol_table[i].type);
    }
    printf("\n\n");
}

int search(char *type)
{
    int i;
    for (i = count - 1; i >= 0; i--)
    {
        if (strcmp(symbol_table[i].id_name, type) == 0)
        {
            printf("Variabila a fost deja declarata.");
            return -1;
            break;
        }
    }
    return 0;
}

int searchInTable(char *type)
{
    int i;
    for (i = count - 1; i >= 0; i--)
    {
        if (strcmp(symbol_table[i].id_name, type) == 0)
        {
            return i;
            break;
        }
    }
    return 0;
}

void add(char *c)
{
    q = search(yytext);

    if (!q)
    {
        if (strcmp(c, "Variable") == 0)
        {
            symbol_table[count].id_name = strdup(yytext);
            symbol_table[count].data_type = strdup(type);

            symbol_table[count].value = atoi(yytext);
            symbol_table[count].type = strdup("Variable");
            count++;
        }
        else if (strcmp(c, "Structure") == 0)
        {
            symbol_table[count].id_name = strdup(yytext);
            symbol_table[count].data_type = strdup("N/A");

            symbol_table[count].value = atoi(yytext);

            symbol_table[count].type = strdup("Structure");
            count++;
        }
        else if (strcmp(c, "Function") == 0)
        {
            symbol_table[count].id_name = strdup(yytext);
            symbol_table[count].data_type = strdup(type);

            symbol_table[count].value = atoi(yytext);

            symbol_table[count].type = strdup("Function");
            count++;
        }
    }
}

void insert_type()
{
    strcpy(type, yytext);
}

int compare_math_operator(char *symbol, int arg1, int arg2)
{
    if (strcmp(symbol, "PLUS") == 0)
    {
        return arg1 + arg2;
    }
    else if (strcmp(symbol, "MINUS") == 0)
    {
        return arg1 - arg2;
    }
    else if (strcmp(symbol, "DIVIDEDBY") == 0)
    {
        return arg1 / arg2;
    }
    else if (strcmp(symbol, "TIMES") == 0)
    {
        return arg1 * arg2;
    }
    else if (strcmp(symbol, "MODULO") == 0)
    {
        return arg1 % arg2;
    }
}

void putInStruct(int indexS, int index, bool cond)
{
    if (cond)
    {
        strcpy(symbol_table[indexS].id_name, ".");
        strcpy(symbol_table[indexS].id_name, symbol_table[index].id_name);
    }
}

int declarationCheck(char *x)
{
    for (int i = count - 1; i >= 0; i--)
    {
        if (strcmp(symbol_table[i].id_name, type) == 0)
        {
            return i;
        }
    }
    return -1;
}
// void execute(char *operator, char *instruction, char *typeNr, char *typeId)
// {
//     if(strcmp(instruction, "IF") == 0)
//     {

//     }
//     else if(strcmp(instruction, "WHILE") == 0)
//     {
//         if()
//     }
// }
